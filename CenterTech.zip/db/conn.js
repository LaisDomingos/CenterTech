const mongoose = require("mongoose")

async function main(){
    try{
        mongoose.set("strictQuery", true) 
        await mongoose.connect( //Testar a conecção com o mongoose
            "mongodb+srv://Lais:eNhQbUOznpdzhfCD@cluster0.terfb13.mongodb.net/?retryWrites=true&w=majority"
        )
        console.log('Conectado ao DB')
    } catch(error){
        console.log(`Erro ${error}`)
    }
}

module.exports = main