const router = require("express").Router()

//Cursos router
const cursosRouter = require("./cursos.js")

router.use("/", cursosRouter) 

//Aluno router
const alunosRouter = require("./alunos.js")

router.use("/", alunosRouter) 

//Professor router
const professoresRouter = require("./professores.js")
router.use("/", professoresRouter) 

module.exports = router;