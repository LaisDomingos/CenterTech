const router = require("express").Router()

const professoresController = require("../controllers/professoresController.js");


router.route("/professores").post((req,res) => professoresController.create(req,res))

router.route("/professores").post((req,res) => professoresController.create(req,res))

router.route("/professores").get((req,res) => professoresController.getAll(req,res))

router.route("/professores/:id").get((req,res) => professoresController.get(req,res))

router.route("/professores/:id").delete((req,res) => professoresController.delete(req,res))

router.route("/professores/:id").put((req,res) => professoresController.update(req,res))

module.exports = router;