const router = require("express").Router()

const alunosController = require("../controllers/alunosController.js");

router.route("/alunos").post((req,res) => alunosController.create(req,res))

router.route("/alunos").get((req,res) => alunosController.getAll(req,res))

router.route("/alunos/:id").get((req,res) => alunosController.get(req,res))

router.route("/alunos/:id").delete((req,res) => alunosController.delete(req,res))

router.route("/alunos/:id").put((req,res) => alunosController.update(req,res))

module.exports = router;