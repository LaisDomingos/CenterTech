const router = require("express").Router()

const cursosController = require("../controllers/cursosController.js");


router.route("/cursos").post((req,res) => cursosController.create(req,res))

router.route("/cursos").get((req,res) => cursosController.getAll(req,res))

router.route("/cursos/:id").get((req,res) => cursosController.get(req,res))

router.route("/cursos/:id").delete((req,res) => cursosController.delete(req,res))

router.route("/cursos/:id").put((req,res) => cursosController.update(req,res))




module.exports = router;