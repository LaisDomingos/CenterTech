//HTTP SERVER
const express = require('express')
var cors = require('cors')
const app = express()
const port = 3000

app.use(cors())

app.use(express.json())

app.use(express.static('public'))

//DB Connection
const conn = require("./db/conn");

conn();


//Routes
const routes = require("./routes/router.js")

app.use('/api', routes)

app.listen(
  port, function() {
  console.log(`Example app listening on port ${port}`) 
})

