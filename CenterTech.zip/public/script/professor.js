let formProf = document.getElementById('formInserirProf')
let br = document.createElement('br')


//Formulários de Inserir
function inserirProf(){
    //Get da div e styles
    formProf.innerHTML = ''
    formProf.style.margin = "1em 5em 1em 5em"
    formProf.style.padding = "1em 10px 1em 10px"

    //Titulo e styles dele
    let titulo = document.createElement('h4')
    titulo.innerHTML='Inserir Professor'
    titulo.style.color='red'
    titulo.style.margin = "0 0 1em 2em"

    //Input Nome e styles
    let labelNome = document.createElement('label')
    labelNome.innerHTML = 'Nome do Professor: '
    let inputNome = document.createElement('input')
    inputNome.setAttribute('id', 'nomeProf')
    labelNome.style.margin = "0 1em 1em 0em"
    inputNome.style.margin = "0 2em 1em 0"
    inputNome.style.width = '150px'

    //Input professor responsável e styles
    let dtNascimento = document.createElement('label')
    dtNascimento.innerHTML = 'Data de Nascimento: '
    let inputDt = document.createElement('input')
    inputDt.setAttribute('id', 'dtNascimentoProf')
    inputDt.style.width = '150px'
    dtNascimento.style.margin = "0 1em 1em 0"

    //input curso e styles
    let p = document.createElement('p')
    let cursos = document.createElement('label')
    cursos.innerHTML = 'Curso Responsável: '
    let inputCursos = document.createElement('input')
    inputCursos.setAttribute('id', 'cursoR')
    inputCursos.style.width = '250px'
    inputCursos.style.height='20px'
    inputCursos.style.margin = "0 1em 0em 1em"

    //Botao
    let botaoCadastrar = document.createElement('button')
    botaoCadastrar.innerHTML = 'Cadastrar'
    botaoCadastrar.setAttribute('onclick', 'cadastrarProf()')
    botaoCadastrar.style.margin = '0em 1em 0em 0em'

    let botaoFechar = document.createElement('button')
    botaoFechar.innerHTML = 'Fechar'
    botaoFechar.setAttribute('onclick', 'fechar()')
    botaoFechar.style.margin = '0em 1em 0em 0em'

    //appends
    formProf.appendChild(titulo)  
    formProf.appendChild(labelNome)
    formProf.appendChild(inputNome)
    
    formProf.appendChild(dtNascimento)
    formProf.appendChild(inputDt)

    p.appendChild(cursos)
    p.appendChild(inputCursos)
    formProf.appendChild(p)
   

    formProf.appendChild(botaoCadastrar)
    formProf.appendChild(botaoFechar)
}

function fechar(){
    formProf.innerHTML = ''
    formProf.style.margin = '0 0 0 0'
}

let profCadastrados = document.getElementById('professoresCadastrados')

//Criar elementos
let criarElementProf = (item) => {
    let template = document.getElementById('professoresTemplate')
    let profElement = document.importNode(template.content, true) //Clone completo

    let itens_prof = profElement.querySelectorAll('span')
    itens_prof[0].innerText = item._id
    itens_prof[1].innerText = item.nome
    itens_prof[2].innerText = item.dtNascimento
    itens_prof[3].innerText = item.curso

    return profElement
}

//Mostrar os alunos cadastradaos
window.onload = () => { //Quando carregar a página já aparece
    (async function() {
        try {
            const headers = {
                'Contente-Type': 'application/json'
            };
            const init = {
                method: 'GET',
                headres: headers
            };
            const response = await fetch('http://localhost:3000/api/professores', init)
            const jsonData = await response.json(); //passar o response para um json
    
            jsonData.forEach(item => {
               
                let  profElement = criarElementProf(item)
                profCadastrados.append(profElement)
    
            })
    } catch (error){ //capturar o erro
        console.log(error)
    }
    }) ();
}

//Cadastrar professor
let cadastrarProf = async () => {
    let nomeProf = document.getElementById('nomeProf')
    let dtNascimentoProf = document.getElementById('dtNascimentoProf')
    let cursoResponsavel = document.getElementById('cursoR')
    if (nomeProf.value.length == 0 || dtNascimentoProf.value.length == 0 || cursoResponsavel.value.length == 0){
        alert('Insira os Dados')
    } else{
        
        let professor ={
            nome: nomeProf.value,
            dtNascimento: dtNascimentoProf.value,
            curso: cursoResponsavel.value
        }

        let init = {
            method: 'POST',
            headers: {
                'Content-Type': "application/json"
            },
            body: JSON.stringify(professor)
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/professores',init)
        let jsonData = await response.json()

        //Adcionar novo professor
        let  profElement = criarElementProf(jsonData)
        profCadastrados.append(profElement)
        alert('Professor cadastrado')
        nomeProf.value=''
        dtNascimentoProf.value=''
        cursoResponsavel.value=''
    }
    
   
}

//Formulário Editar
function editarProf(){  
    formProf.innerHTML = ''
    formProf.style.margin = "1em 5em 1em 5em"
    formProf.style.padding = "1em 10px 1em 10px"

    //Campo id
    let idCampo = document.createElement('input')
    idCampo.setAttribute('id', 'idPesquisar')
    idCampo.setAttribute('placeholder', 'Insira o ID que deseja editar')
    idCampo.style.width='95%'

    //Campo curso e prof
    let nomeEditar = document.createElement('input')
    let dtNascimentoEditar = document.createElement('input')
    let cursoMatriculado = document.createElement('input')
    nomeEditar.setAttribute('placeholder', 'Nome')
    nomeEditar.setAttribute('id', 'editarNomeProf')
    dtNascimentoEditar.setAttribute('placeholder', 'Data de Nascimento')
    dtNascimentoEditar.setAttribute('id','editarDataProf')
    cursoMatriculado.setAttribute('placeholder', 'Curso Responsável')
    cursoMatriculado.setAttribute('id','editarCursoProf')
    nomeEditar.style.width='45%'
    dtNascimentoEditar.style.width='45%'
    cursoMatriculado.style.width='95%'
    nomeEditar.style.margin='0.5em 0.8em 0.5em 0em'
    dtNascimentoEditar.style.margin='0.5em 0.5em 0.5em 0.8em'
    cursoMatriculado.style.margin='0.5em 0.5em 0.5em 0em'

    //Botão
    let buttonEditar = document.createElement('button')
    buttonEditar.innerHTML='Editar'
    buttonEditar.style.margin = '1em 1em 1em 0em'
    buttonEditar.setAttribute('onclick', 'campoEditarProf()')
    
    //Mostrar na tela
    formProf.appendChild(idCampo)
    formProf.appendChild(nomeEditar)
    formProf.appendChild(dtNascimentoEditar)
    formProf.appendChild(cursoMatriculado)
    formProf.appendChild(br)
    formProf.appendChild(buttonEditar)
   
}

//Editar professor
let campoEditarProf = async () => {
    let id = document.getElementById('idPesquisar').value
    let nomeProf = document.getElementById('editarNomeProf')
    let dataProf = document.getElementById('editarDataProf')
    let cursoResponsavel = document.getElementById('editarCursoProf')
    if(id.length == 0 ) {
        alert('Inserir os dados')
    }else{
        let professor ={
            nome: nomeProf.value,
            dtNascimento: dataProf.value,
            curso: cursoResponsavel.value
        }

        let init = {
            method: 'PUT',
            headers: {
                'Content-Type': "application/json"
            },
            body: JSON.stringify(professor)
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/professores/'+id,init)
        let jsonData = await response.json()
        console.log(jsonData)

        //Adcionar a edição do professor
        let  profElement = criarElementProf(jsonData)
        profCadastrados.append(profElement)
        alert('Professor editado')
        id.value= ''
        nomeProf.value=''
        dataProf.value=''
        cursoResponsavel.value='' 
    }
}

//Formulário remover
function removerProf(){
    formProf.innerHTML=''
    formProf.style.margin = "1em 5em 1em 5em"
    formProf.style.padding = "1em 10px 1em 10px"

    //input
    let id = document.createElement('input')
    id.setAttribute('placeholder', 'Insira o ID que deseja excluir')
    id.setAttribute('id','idExcluir')
    id.style.width='95%'

    //botão
    let buttonRemover = document.createElement('button')
    buttonRemover.setAttribute('onclick','campoRemoverProf()')
    buttonRemover.innerHTML='Excluir'
    buttonRemover.style.margin = '1em 1em 1em 0em'

    //Mostrar na Tela
    formProf.appendChild(id)
    formProf.appendChild(buttonRemover)

   
}

//Remover professor
let campoRemoverProf = async () => {
    let idExcluir = document.getElementById('idExcluir').value
    if (idExcluir.length == 0){
        alert('O usuário não inseriu nenhum dado para editar')
    } else {
      

        let init = {
            method: 'DELETE',
            headers: {
                'Content-Type': "application/json"
            }
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/professores/'+idExcluir,init)
        let jsonData = await response.json()
        alert("Professor Excluído")
        console.log(jsonData)
        

    }
}

