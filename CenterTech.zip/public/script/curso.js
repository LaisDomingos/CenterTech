let formCurso = document.getElementById('formInserirCursos')
let br = document.createElement('br')

//Formulários de Inserir
function inserirCursos(){
    //Get da div e styles
    formCurso.innerHTML = ''
    formCurso.style.margin = "1em 5em 1em 5em"
    formCurso.style.padding = "1em 10px 1em 10px"

    //Titulo e styles dele
    let titulo = document.createElement('h4')
    titulo.innerHTML='Inserir Curso'
    titulo.style.color='red'
    titulo.style.margin = "0 0 1em 2em"

    //Input Nome e styles
    let labelNome = document.createElement('label')
    labelNome.innerHTML = 'Nome do Curso: '
    let inputNome = document.createElement('input')
    inputNome.setAttribute('id', 'nomeCurso')
    labelNome.style.margin = "0 1em 1em 0em"
    inputNome.style.margin = "0 2em 1em 0"
    inputNome.style.width = '150px'

    //Input professor responsável e styles
    let profResponsavel = document.createElement('label')
    profResponsavel.innerHTML = 'Professor Responsável: '
    let inputProf = document.createElement('input')
    inputProf.setAttribute('id', 'profResponsavel')
    inputProf.style.width = '150px'
    profResponsavel.style.margin = "0 1em 1em 0"

    //Botao
    let botaoCadastrar = document.createElement('button')
    botaoCadastrar.innerHTML = 'Cadastrar'
    botaoCadastrar.setAttribute('onclick', 'cadastrarCurso()')
    botaoCadastrar.style.margin = '1em 1em 1em 0em'

    let botaoFechar = document.createElement('button')
    botaoFechar.innerHTML = 'Fechar'
    botaoFechar.setAttribute('onclick', 'fechar()')
    botaoFechar.style.margin = '1em 1em 1em 0em'

    //Appends
    formCurso.appendChild(titulo)  
    formCurso.appendChild(labelNome)
    formCurso.appendChild(inputNome)
    
    formCurso.appendChild(profResponsavel)
    formCurso.appendChild(inputProf)
    formCurso.appendChild(br)
    formCurso.appendChild(botaoCadastrar)
    formCurso.appendChild(botaoFechar)
}

//Fechar
function fechar(){
    formCurso.innerHTML = ''
    formCurso.style.margin = '0 0 0 0'
}


let cursosCadastrados = document.getElementById('cursosCadastrados')

//Criar elementos
let criarElement = (item) => {
    let template = document.getElementById('cursosTemplate')
    let cursoElement = document.importNode(template.content, true) //Clone completo

    let itens_cursos = cursoElement.querySelectorAll('span')
    itens_cursos[0].innerHTML = item._id
    itens_cursos[1].innerText = item.nome
    itens_cursos[2].innerText = item.profResponsavel

    return cursoElement
}

//Mostrar os cursos cadastradaos
window.onload = () => { //Quando carregar a página já aparece
    (async function() {
        try {
            const headers = {
                'Contente-Type': 'application/json'
            };
            const init = {
                method: 'GET',
                headres: headers
            };
            const response = await fetch('http://localhost:3000/api/cursos', init)
            const jsonData = await response.json(); //passar o response para um json
    
            jsonData.forEach(item => {
               
                let  cursoElement = criarElement(item)
                cursosCadastrados.append(cursoElement)
    
            })
    } catch (error){ //capturar o erro
        console.log(error)
    }
    }) ();
}

//Cadastrar curso
let cadastrarCurso = async () => {
    let nome = document.getElementById('nomeCurso')
    let profResponsavel = document.getElementById('profResponsavel')
    if (nome.value.length == 0 || profResponsavel.value.length == 0 ){
        alert('Insira os Dados')
    } else{
        
        
        let curso ={
            nome: nome.value,
            profResponsavel: profResponsavel.value
        }

        let init = {
            method: 'POST',
            headers: {
                'Content-Type': "application/json"
            },
            body: JSON.stringify(curso)
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/cursos',init)
        let jsonData = await response.json()
        console.log(jsonData)

        //Adcionar novo Curso
        let  cursoElement = criarElement(jsonData)
        cursosCadastrados.append(cursoElement)
        alert('Curso cadastrado')
        nome.value=''
        profResponsavel.value='' 
    }
} 


//Formulário de editar cursos
function editarCursos(){
    formCurso.innerHTML = ''
    formCurso.style.margin = "1em 5em 1em 5em"
    formCurso.style.padding = "1em 10px 1em 10px"

    //Campo id
    let idCampo = document.createElement('input')
    idCampo.setAttribute('id', 'idPesquisar')
    idCampo.setAttribute('placeholder', 'Insira o ID que deseja editar')
    idCampo.style.width='95%'

    //Campo curso e prof
    let nomeEditar = document.createElement('input')
    let profResponsavel = document.createElement('input')
    nomeEditar.setAttribute('placeholder', 'Nome')
    nomeEditar.setAttribute('id', 'editarNome')
    profResponsavel.setAttribute('placeholder', 'Professor')
    profResponsavel.setAttribute('id','editarProf')
    nomeEditar.style.width='45%'
    profResponsavel.style.width='45%'
    nomeEditar.style.margin='0.5em 0.8em 0.5em 0em'
    profResponsavel.style.margin='0.5em 0.5em 0.5em 0.8em'

    //Botão
    let buttonEditar = document.createElement('button')
    buttonEditar.innerHTML='Editar'
    buttonEditar.style.margin = '1em 1em 1em 1em'
    buttonEditar.setAttribute('onclick', 'campoEditarCursos()')
    
    //Mostrar na tela
    formCurso.appendChild(idCampo)
    formCurso.appendChild(nomeEditar)
    formCurso.appendChild(profResponsavel)
    formCurso.appendChild(br)
    formCurso.appendChild(buttonEditar)
   
}

//Editar curso
let campoEditarCursos = async () => {
    let id = document.getElementById('idPesquisar').value
    let curso = document.getElementById('editarNome')
    let prof = document.getElementById('editarProf')
    if(id.length == 0 ) {
        alert('Inserir os dados')
    }else{
        let cursoE ={
            nome: curso.value,
            profResponsavel: prof.value
        }

        let init = {
            method: 'PUT',
            headers: {
                'Content-Type': "application/json"
            },
            body: JSON.stringify(cursoE)
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/cursos/'+id,init)
        let jsonData = await response.json()
        console.log(jsonData)

        //Adcionar a edição do Curso
        let  cursoElement = criarElement(jsonData)
        cursosCadastrados.append(cursoElement)
        alert('Curso editado')
        id.value= ''
        curso.value=''
        prof.value='' 
    }
   
}

//Fomulário remover
function removerCursos(){
    formCurso.innerHTML=''
    formCurso.style.margin = "1em 5em 1em 5em"
    formCurso.style.padding = "1em 10px 1em 10px"

    //input
    let id = document.createElement('input')
    id.setAttribute('placeholder', 'Insira o ID que deseja excluir')
    id.setAttribute('id','idExcluir')
    id.style.width='95%'

    //botão
    let buttonRemover = document.createElement('button')
    buttonRemover.setAttribute('onclick','campoRemoverCursos()')
    buttonRemover.innerHTML='Excluir'
    buttonRemover.style.margin = '1em 1em 1em 0em'

    //Append
    formCurso.appendChild(id)
    formCurso.appendChild(buttonRemover)
}

//Remover
let campoRemoverCursos = async () => {
    let idExcluir = document.getElementById('idExcluir').value
    if (idExcluir.length == 0){
        alert('O usuário não inseriu nenhum dado para editar')
    } else {
      

        let init = {
            method: 'DELETE',
            headers: {
                'Content-Type': "application/json"
            }
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/cursos/'+idExcluir,init)
        let jsonData = await response.json()
        alert("Curso Excluído")
        console.log(jsonData)
        

    }
}



