let formAluno = document.getElementById('formInserirAlunos')
let br = document.createElement('br')

//Formulários de Inserir
function inserirAlunos(){
    //Get da div e styles
    formAluno.innerHTML = ''
    formAluno.style.margin = "1em 5em 1em 5em"
    formAluno.style.padding = "1em 10px 1em 10px"

    //Titulo e styles dele
    let titulo = document.createElement('h4')
    titulo.innerHTML='Inserir Aluno'
    titulo.style.color='red'
    titulo.style.margin = "0 0 1em 2em"

    //Input Nome e styles
    let labelNome = document.createElement('label')
    labelNome.innerHTML = 'Nome do Aluno: '
    let inputNome = document.createElement('input')
    inputNome.setAttribute('id', 'nomeAluno')
    labelNome.style.margin = "0 1em 1em 0em"
    inputNome.style.margin = "0 2em 1em 0"
    inputNome.style.width = '150px'

    //Input professor responsável e styles
    let dtNascimento = document.createElement('label')
    dtNascimento.innerHTML = 'Data de Nascimento: '
    let inputDt = document.createElement('input')
    inputDt.setAttribute('id', 'dtNascimento')
    inputDt.style.width = '150px'
    dtNascimento.style.margin = "0 1em 1em 0"

    //input curso e styles
    let p = document.createElement('p')
    let cursos = document.createElement('label')
    cursos.innerHTML = 'Curso Matriculado: '
    let inputCursos = document.createElement('input')
    inputCursos.setAttribute('id', 'cursoM')
    inputCursos.style.width = '250px'
    inputCursos.style.height='20px'
    inputCursos.style.margin = "0 1em 0em 1em"

   //Botao
   let botaoCadastrar = document.createElement('button')
   botaoCadastrar.innerHTML = 'Cadastrar'
   botaoCadastrar.setAttribute('onclick', 'cadastrarAluno()')
   botaoCadastrar.style.margin = '1em 1em 1em 0em'

   let botaoFechar = document.createElement('button')
   botaoFechar.innerHTML = 'Fechar'
   botaoFechar.setAttribute('onclick', 'fechar()')
   botaoFechar.style.margin = '1em 1em 1em 0em'


    //appends
    formAluno.appendChild(titulo)  
    formAluno.appendChild(labelNome)
    formAluno.appendChild(inputNome)
    
    formAluno.appendChild(dtNascimento)
    formAluno.appendChild(inputDt)

    p.appendChild(cursos)
    p.appendChild(inputCursos)
    formAluno.appendChild(p)
   

    formAluno.appendChild(botaoCadastrar)
    formAluno.appendChild(botaoFechar)
}

function fechar(){
    formAluno.innerHTML = ''
    formAluno.style.margin = '0 0 0 0'
   
}

let alunoCadastrados = document.getElementById('alunosCadastrados')

//Criar elementos
let criarElementAluno = (item) => {
    let template = document.getElementById('alunosTemplate')
    let alunoElement = document.importNode(template.content, true) //Clone completo

    let itens_aluno = alunoElement.querySelectorAll('span')
    itens_aluno[0].innerText = item._id
    itens_aluno[1].innerText = item.nome
    itens_aluno[2].innerText = item.dtNascimento
    itens_aluno[3].innerText = item.curso

    return alunoElement
}

//Mostrar os alunos cadastradaos
window.onload = () => { //Quando carregar a página já aparece
    (async function() {
        try {
            const headers = {
                'Contente-Type': 'application/json'
            };
            const init = {
                method: 'GET',
                headres: headers
            };
            const response = await fetch('http://localhost:3000/api/alunos', init)
            const jsonData = await response.json(); //passar o response para um json
    
            jsonData.forEach(item => {
               
                let  alunoElement = criarElementAluno(item)
                alunoCadastrados.append(alunoElement)
    
            })
    } catch (error){ //capturar o erro
        console.log(error)
    }
    }) ();
}

//Cadastrar aluno
let cadastrarAluno = async () => {
    let nome = document.getElementById('nomeAluno')
    let dtNascimento = document.getElementById('dtNascimento')
    let cursoMatriculado = document.getElementById('cursoM')
    if (nome.value.length == 0 || dtNascimento.value.length == 0 || cursoMatriculado.value.length == 0){
        alert('Insira os Dados')
    } else{
        
        
        let alunos ={
            nome: nome.value,
            dtNascimento: dtNascimento.value,
            curso: cursoMatriculado.value
        }

        let init = {
            method: 'POST',
            headers: {
                'Content-Type': "application/json"
            },
            body: JSON.stringify(alunos)
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/alunos',init)
        let jsonData = await response.json()

        //Adcionar novo aluno
        let  alunoElement = criarElementAluno(jsonData)
        alunoCadastrados.append(alunoElement)
        alert('Aluno cadastrado')
        nome.value=''
        dtNascimento.value=''
        cursoMatriculado.value=''
    }
    
   
}


//Formulário editar
function editarAlunos(){
    formAluno.innerHTML = ''
    formAluno.style.margin = "1em 5em 1em 5em"
    formAluno.style.padding = "1em 10px 1em 10px"

    //Campo id
    let idCampo = document.createElement('input')
    idCampo.setAttribute('id', 'idPesquisar')
    idCampo.setAttribute('placeholder', 'Insira o ID que deseja editar')
    idCampo.style.width='95%'

    //Campo curso e prof
    let nomeEditar = document.createElement('input')
    let dtNascimentoEditar = document.createElement('input')
    let cursoMatriculado = document.createElement('input')
    nomeEditar.setAttribute('placeholder', 'Nome')
    nomeEditar.setAttribute('id', 'editarNome')
    dtNascimentoEditar.setAttribute('placeholder', 'Data de Nascimento')
    dtNascimentoEditar.setAttribute('id','editarData')
    cursoMatriculado.setAttribute('placeholder', 'Curso Matriculado')
    cursoMatriculado.setAttribute('id','editarCurso')
    nomeEditar.style.width='45%'
    dtNascimentoEditar.style.width='45%'
    cursoMatriculado.style.width='95%'
    nomeEditar.style.margin='0.5em 0.8em 0.5em 0em'
    dtNascimentoEditar.style.margin='0.5em 0.5em 0.5em 0.8em'
    cursoMatriculado.style.margin='0.5em 0.5em 0.5em 0em'

    //Botão
    let buttonEditar = document.createElement('button')
    buttonEditar.innerHTML='Editar'
    buttonEditar.style.margin = '1em 1em 1em 1em'
    buttonEditar.setAttribute('onclick', 'campoEditarAlunos()')
    
    
    //Mostrar na tela
    formAluno.appendChild(idCampo)
    formAluno.appendChild(nomeEditar)
    formAluno.appendChild(dtNascimentoEditar)
    formAluno.appendChild(cursoMatriculado)
    formAluno.appendChild(br)
    formAluno.appendChild(buttonEditar)
   
}

//Editar aluno
let campoEditarAlunos = async () => {
    let id = document.getElementById('idPesquisar').value
    let nome = document.getElementById('editarNome')
    let data = document.getElementById('editarData')
    let cursoMatriculado = document.getElementById('editarCurso')
    if(id.length == 0 ) {
        alert('Inserir os dados')
    }else{
        let aluno ={
            nome: nome.value,
            dtNascimento: data.value,
            curso: cursoMatriculado.value
        }

        let init = {
            method: 'PUT',
            headers: {
                'Content-Type': "application/json"
            },
            body: JSON.stringify(aluno)
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/alunos/'+id,init)
        let jsonData = await response.json()
        console.log(jsonData)

        //Adcionar a edição do aluno
        let  alunoElement = criarElementAluno(jsonData)
        alunoCadastrados.append(alunoElement)
        alert('Aluno editado')
        id.value= ''
        nome.value=''
        data.value=''
        cursoMatriculado.value='' 
    }
}

//Remover
function removerAlunos(){
    formAluno.innerHTML=''
    formAluno.style.margin = "1em 5em 1em 5em"
    formAluno.style.padding = "1em 10px 1em 10px"

    //input
    let id = document.createElement('input')
    id.setAttribute('placeholder', 'Insira o ID que deseja excluir')
    id.setAttribute('id','idExcluir')
    id.style.width='95%'

    //botão
    let buttonRemover = document.createElement('button')
    buttonRemover.setAttribute('onclick','campoRemoverAluno()')
    buttonRemover.innerHTML='Excluir'
    buttonRemover.style.margin = '1em 1em 1em 0em'

    //Mostrar na Tela
    formAluno.appendChild(id)
    formAluno.appendChild(buttonRemover)

}

//Remover
let campoRemoverAluno = async () => {
    let idExcluir = document.getElementById('idExcluir').value
    if (idExcluir.length == 0){
        alert('O usuário não inseriu nenhum dado para editar')
    } else {
      

        let init = {
            method: 'DELETE',
            headers: {
                'Content-Type': "application/json"
            }
        }

        //Chamar API
        let response = await fetch('http://localhost:3000/api/alunos/'+idExcluir,init)
        let jsonData = await response.json()
        alert("Aluno Excluído")
        console.log(jsonData)
        

    }
}
