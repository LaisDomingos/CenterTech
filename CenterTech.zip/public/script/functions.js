let username = document.getElementById('username')
let senha = document.getElementById('senha')
let resultado = document.getElementById('resultado')
let loginEfetuado = false

//Login
function login(){
        
        if(username.value.length !=0 && senha.value.length != 0 ){
            
            if (username.value == 'Adm' && senha.value == 'teste123'){
                resultado.innerHTML=''
                location.href = "../ficheiros/gestao.html";
                loginEfetuado = true
            } else{
                resultado.style.color='red'
                resultado.style.fontSize='0.5em'
                let incorreta = document.createElement('p')
                incorreta.innerHTML='Username ou senha incorreta'
                resultado.appendChild(incorreta)
            
            }    
        } else{
            alert('Insira os dados!')
        } 
}


//Conferir se o login foi efetuado
function professor(){
    if(loginEfetuado == true){
        location.href = "../ficheiros/professores.html";
    } else{
        location.href = "../ficheiros/login.html";
    }
}

function aluno(){
    if(loginEfetuado==true){
        location.href = "../ficheiros/professores.html";
        
    } else{
        location.href = "../ficheiros/login.html";
    }
}

function curso(){
    if(loginEfetuado==true){
        location.href = "../ficheiros/professores.html";
    } else{
        location.href = "../ficheiros/login.html";
    }
}














