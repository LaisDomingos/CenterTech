const { ProfessoresR: ProfResponsavelModel } = require("../models/professores.js");

const professoresController = {
    create: async(req,res) => {
        try {
            
            const professores = {
                nome:req.body.nome, 
                dtNascimento: req.body.dtNascimento,
                curso: req.body.curso
            }

            const response = await ProfResponsavelModel.create(professores); //Para inserir no BD

            res.status(201).json({response, msg: "Professor criado com sucesso!"})
        }catch(error){
            console.log(error)
        }
    },
    getAll: async (req,res) => {
        try {
            const professores = await ProfResponsavelModel.find() //pegar todos os cursos

            res.json(professores);
        } catch(error){
            console.log(error)
        }
    }, 
    get: async(req,res) => {
        try{
            //id => URL === GET
            const id = req.params.id
            const professores = await ProfResponsavelModel.findById(id)

            //Caso o id não exista
            if (!professores){
                res.status(404).json({ msg: "Professor não encontrado." })
                return
            }

            res.json(professores);

        } catch(error){
            console.log(error)
        }
    },
    delete: async(req,res) => {
        try{
            const id = req.params.id
            const professores = await ProfResponsavelModel.findById(id)
           
            if (!professores){
                res.status(404).json({ msg: "Professor não encontrado." })
                return
            }
            const deleteProfessor = await ProfResponsavelModel.findByIdAndDelete(id)//Econtrar o id e deletar

            res.status(200).json({deleteProfessor, msg: "Professor excluído com sucesso."})

        } catch(error){
            console.log(error)
        }
    }, 
    update: async (req,res) => {
        const id = req.params.id
        
        const professores = {
            nome: req.body.nome, 
            dtNascimento: req.body.dtNascimento,
            curso: req.body.curso
        }

        const updateProfessores = await ProfResponsavelModel.findByIdAndUpdate(id, professores)

        if (!updateProfessores){
            res.status(404).json({ msg: "Professor não encontrado." })
            return
        }
        

        res.status(200).json({professores, msg: "Professor editado com sucesso."})


    }
}

module.exports = professoresController;