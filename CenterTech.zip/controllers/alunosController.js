const { Alunos: AlunosModel } = require("../models/alunos.js");

const alunosController = {
    create: async(req,res) => {
        try {
            
            const alunos = {
                nome:req.body.nome, 
                dtNascimento: req.body.dtNascimento,
                curso: req.body.curso
            }

            const response = await AlunosModel.create(alunos); //Para inserir no BD

            res.status(201).json({response, msg: "Aluno criado com sucesso!"})
        }catch(error){
            console.log(error)
        }
    },
    getAll: async (req,res) => {
        try {
            const alunos = await AlunosModel.find() //pegar todos os cursos

            res.json(alunos);
        } catch(error){
            console.log(error)
        }
    }, 
    get: async(req,res) => {
        try{
            //id => URL === GET
            const id = req.params.id
            const alunos = await AlunosModel.findById(id)

            //Caso o id não exista
            if (!alunos){
                res.status(404).json({ msg: "Aluno não encontrado." })
                return
            }

            res.json(alunos);

        } catch(error){
            console.log(error)
        }
    },
    delete: async(req,res) => {
        try{
            const id = req.params.id
            const alunos = await AlunosModel.findById(id)
           
            if (!alunos){
                res.status(404).json({ msg: "Aluno não encontrado." })
                return
            }
            const deleteAlunos = await AlunosModel.findByIdAndDelete(id)//Econtrar o id e deletar

            res.status(200).json({deleteAlunos, msg: "Aluno excluído com sucesso."})

        } catch(error){
            console.log(error)
        }
    }, 
    update: async (req,res) => {
        const id = req.params.id
        
        const alunos = {
            nome: req.body.nome, 
            dtNascimento: req.body.dtNascimento,
            curso: req.body.curso
        }

        const updateAlunos = await AlunosModel.findByIdAndUpdate(id, alunos)

        if (!updateAlunos){
            res.status(404).json({ msg: "Aluno não encontrado." })
            return
        }
        

        res.status(200).json({alunos, msg: "Aluno editado com sucesso."})


    }
}

module.exports = alunosController;