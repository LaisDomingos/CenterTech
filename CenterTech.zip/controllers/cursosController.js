const { Cursos: CursosModel } = require("../models/cursos.js");

const cursosController = {
    create: async(req,res) => {
        try {
            
            const cursos = {
                nome: req.body.nome, 
                profResponsavel: req.body.profResponsavel
            }

            const response = await CursosModel.create(cursos); //Para inserir no BD

            res.status(201).json({response, msg: "Curso criado com sucesso!"})
        }catch(error){
            console.log(error)
        }
    },
    getAll: async (req,res) => {
        try {
            const cursos = await CursosModel.find() //pegar todos os cursos

            res.json(cursos);
        } catch(error){
            console.log(error)
        }
    }, 
    get: async(req,res) => {
        try{
            //id => URL === GET
            const id = req.params.id
            const cursos = await CursosModel.findById(id)

            //Caso o id não exista
            if (!cursos){
                res.status(404).json({ msg: "Curso não encontrado." })
                return
            }

            res.json(cursos);

        } catch(error){
            console.log(error)
        }
    },
    delete: async(req,res) => {
        try{
            const id = req.params.id
            const cursos = await CursosModel.findById(id)
           
            if (!cursos){
                res.status(404).json({ msg: "Curso não encontrado." })
                return
            }
            const deleteCurso = await CursosModel.findByIdAndDelete(id)//Econtrar o id e deletar

            res.status(200).json({deleteCurso, msg: "Curso excluído com sucesso."})

        } catch(error){
            console.log(error)
        }
    }, 
    update: async (req,res) => {
        const id = req.params.id
        
        const cursos = {
            nome: req.body.nome, 
            profResponsavel: req.body.profResponsavel
        }

        const updateCursos = await CursosModel.findByIdAndUpdate(id, cursos)

        if (!updateCursos){
            res.status(404).json({ msg: "Curso não encontrado." })
            return
        }
        

        res.status(200).json({cursos, msg: "Curso editado com sucesso."})


    }
}
module.exports = cursosController;