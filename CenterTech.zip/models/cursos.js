const mongoose = require("mongoose")

const { Schema } = mongoose; //esqueleto do models

const cursosSchema = new Schema({
    nome:{
        type: String,
        required: true //Obrigatório
    },
    profResponsavel:{
        type: String,
        required: true
    }
}, {timestamps: true} //salva a data de criação e de atualização
);


const Cursos = mongoose.model("Cursos", cursosSchema)

module.exports = {
    Cursos,
    cursosSchema,
};