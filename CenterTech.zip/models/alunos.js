
const mongoose = require("mongoose");


const { Schema } = mongoose; //esqueleto do models

const alunosSchema = new Schema({
    nome:{
        type: String,
        required: true //Obrigatório
    },
    dtNascimento:{
        type: String,
        required: true
    },
    curso:{
        type: String,
        required: true
    },
}, {timestamps: true} //salva a data de criação e de atualização
);


const Alunos = mongoose.model("Alunos", alunosSchema)

module.exports = {
    Alunos
};