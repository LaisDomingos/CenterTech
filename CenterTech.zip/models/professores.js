const mongoose = require("mongoose");
const { cursosSchema } = require("./cursos.js");

const { Schema } = mongoose; //esqueleto do models

const profSchema = new Schema({
    nome:{
        type: String,
        required: true //Obrigatório
    },
    dtNascimento:{
        type: String,
        required: true
    },
    curso:{
        type: String, //só vai aceitar os cursos existentes
        required: true
    },
}, {timestamps: true} //salva a data de criação e de atualização
);


const ProfessoresR = mongoose.model("ProfessoresR", profSchema)

module.exports = {
    ProfessoresR
};